#include "sort.h"
void read(int a[], int n)
{
	int i;
	for (i = 0; i < n; i++)
            scanf("%d", &a[i]);
}

void print(int a[], int n)
{
	int i;
	for (i = 0; i < n; i++)
		printf("%d ", a[i]);
	printf("\n");
}

void insertion_sort(int a[], int n)
{
    int  j ,k, i = 1;
    while(i < n){
        j = i -1;
        k = a[i];
        while(j>=0 && k <a[j]){
                a[j+1]=a[j];
                j--;
        }
        a[j+1] = k;
        i++;
    }
}
void selection_sort(int a[], int n)
{
	    int swapper , minIndx ,i , j;
    for(i = 0 ; i< n ; i++){
        minIndx = i;
        for(j = i+1 ; j < n ; j++){
            if(a[minIndx] > a[j]){
                minIndx= j;
            }
        }
        swapper=a[i];
        a[i]=a[minIndx];
        a[minIndx]=swapper;
    }
        
}

void bubble_sort(int a[], int n)
{
	int sortedIndx = n-1 ,swapper , i,j; 
    for(i = sortedIndx ; i>=0  ; i--){
        for(j = 0 ; j<i ; j++){
            if(a[j] > a[j+1]){
                swapper= a[j];
                a[j]=a[j+1];
                a[j+1] = swapper;
            }
        }
    }
	
}
