#include "my_qsort.h"

/*
  quicksort эрэмбэлэх аргын цааш хуваагдах ёсгүй хэмжээ
*/
#ifndef CUTOFF
#define CUTOFF 10
#endif

static int init_seed = 0;  // Random seed 1 удаа эхлүүлнэ

/*
  Оруулан эрэмбэлэх функц.
  [lo, hi] завсрах тоонуудыг оруулан эрэмбэлэх аргаар эрэмбэлнэ.
*/
static void insertion_sort(int a[], int lo, int hi)
{
        /* Оруулан эрэмбэлэх аргыг хэрэгжүүл */
        int  i ,j ,k;
        for(i = lo ; i<=hi ; i++){
                j = i-1;
                k = a[i];
                while ( j>=lo && k<a[j]){
                        a[j+1]=a[j];
                        j--;
                }
                a[j+1] = k;
        }
}

/*
  Хоёр утгыг хооронд солих функц
*/
static void swap(int *a, int *b)
{
        int tmp = *a;
        *a = *b;
        *b = tmp;
}

/*
  [lo, hi] завсрыг санамсаргүйгээр холих функц.
*/
static void random_shuffle(int a[], int lo, int hi)
{
        if (init_seed == 0) {
                srand(time(NULL));
                init_seed = 1;
        }
        int i, j;
        for (i = lo; i <= hi; i++) {
                j = rand() % (hi - lo) + lo;
                swap(&a[i], &a[j]);
        }
}

/*
  1-pivot хурдан эрэмбэлэх функц.
*/
static void _single_pivot_qsort(int a[], int lo, int hi)
{
        /* Энд quicksort хэрэгжүүл */
        if(hi-lo <= CUTOFF){
                insertion_sort(a,lo,hi);
        }
        else if(lo>=hi){
                // yuch hiihgui.
        }
        else{
        int i=lo+1 , j=hi , k=a[lo],l=1 ;
        while(l==1){
                while(a[lo]>=a[i]){
                        i++;
                }
                while(a[lo] < a[j]){
                        j--;
                }
                if (i >= j) break;
                swap(&a[i], &a[j]);
        }
        swap(&a[lo] , &a[j]);
        _single_pivot_qsort(a , lo , j-1);
        _single_pivot_qsort(a , j+1 , hi);
        }
}

/*
  wrapper function for _single_pivot_qsort
  _single_pivot_qsort-ыг дуудахад ашиглах функц
 */
void single_pivot_qsort(int a[], int lo, int hi)
{
        random_shuffle(a, lo, hi);
        _single_pivot_qsort(a, lo, hi);
}

/*
  Dual-pivot хурдан эрэмбэлэх функц
*/
static void _dual_pivot_qsort(int a[], int lo, int hi)
{
        /*
          Энд dual-pivot quicksort хэрэгжүүл
        */
        if(hi - lo <= CUTOFF){
                insertion_sort(a,lo,hi); // Арваас бага элемент байх үед insertsort ашигласан.
                return ;
        }
        if(a[hi]<a[lo]){
        swap(&a[hi],&a[lo]);
        }
        int r=hi-1 ,i=lo+1 ,l=lo+1 , o=1;
        while(o==1){ 
                if(a[i]<a[lo]){  
                        swap(&a[i],&a[l]);
                        i++;
                        l++; 
                }else if(a[i]>a[hi]){ 
                        swap(&a[i],&a[r]);
                        r--; 
                }else{
                        i++; 
                }
                if(i>r)break;
        }
        l--;
        r++;
        swap(&a[lo],&a[l]); 
        swap(&a[hi],&a[r]); 
        _dual_pivot_qsort(a,lo,l-1);  
        _dual_pivot_qsort(a,l+1,r-1);    
        _dual_pivot_qsort(a,r+1,hi);
}
/*
  wrapper function for _dual_pivot_qsort
  _dual_pivot_qsort-ыг дуудахад ашиглах функц
*/
void dual_pivot_qsort(int a[], int lo, int hi)
{
        random_shuffle(a, lo, hi);
        _dual_pivot_qsort(a, lo, hi);
}
