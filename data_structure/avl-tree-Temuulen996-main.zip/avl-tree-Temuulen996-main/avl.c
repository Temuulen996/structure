#include "DS.h"
Elm *createElement(int x){
    Elm *ptr = (Elm *) malloc(sizeof(Elm)) ;
    ptr->x = x ;
    ptr->height = ptr->len = 1 ;
    ptr->R = ptr->L = NULL ;
    return ptr;
}
int max(Elm *a, Elm *b) {
    if(a == NULL && b == NULL) return 0;
    if(a == NULL && b != NULL) return b->height;
    if(a != NULL && b == NULL) return a->height;
    return a->height > b->height ? a->height : b->height;
}
int checkAndGetHeight(Elm *ptr)
{
    if (ptr == NULL)
    {
        return 0;
    }
    return ptr->height;
}
 int len(Elm *ptr)
{
    int a = 1;
    if (ptr->L != NULL)
    {
        a = a + ptr->L->len;
    }

    if (ptr->R != NULL)
    {
        a = a + ptr->R->len;
    }
    return a;
}
int check_Balance(Elm *ptr)
{
    if (ptr == NULL)
    {
        return 0;
    }
    else
    {
        return checkAndGetHeight(ptr->L) - checkAndGetHeight(ptr->R);
    }
}

Elm *rightRotate(Elm *x)
{
    Elm *y = x->L;
    x->L = y->R;
    y->R = x;
    y->len = x->len;
    x->len = len(x);
    x->height = 1 + max(x->L, x->R);
    y->height = 1 + max(y->L, y->R);
    return y;
}
Elm *leftRotate(Elm *x)
{
    Elm *y = x->R;
    x->R = y->L;
    y->L = x;
    y->len = x->len;
    x->len = len(x);
    x->height = 1 + max(x->L, x->R);
    y->height = 1 + max(y->L, y->R);
    return y;
}
Elm *balance(Elm *ptr){

    if (check_Balance(ptr) < -1) {//r ,r
        if (check_Balance(ptr->R) > 0) {
            ptr->R = rightRotate(ptr->R);//r,l
        }
        ptr = leftRotate(ptr);
    }
    else if (check_Balance(ptr) > 1) {//l , l
        if (check_Balance(ptr->L) < 0) {//l,r
            ptr->L = leftRotate(ptr->L);
        }
        ptr = rightRotate(ptr);
    }
    return ptr;
}
void *insert(Elm *ptr, int x)
{
    if (ptr == NULL) ptr = createElement(x);
    else{
        if (ptr->x < x) ptr->R = insert(ptr->R, x);
        else ptr->L = insert(ptr->L, x);
    }
    ptr->height = 1 + max(ptr->L, ptr->R);
    ptr->len = len(ptr);
    balance(ptr);
}
void avl_put(AVL *ptree, int x)
{
    // Функцийг хэрэгжүүлнэ үү
    ptree->root = insert(ptree->root, x);
}

/*
  ptree`-ийн зааж байгаа модноос x` утгыг хайн олдсон оройн Elm* хаягийг буцаана.
  Олдохгүй бол NULL хаягийг буцаана.
  Мод дандаа ялгаатай элементүүд хадгална гэж үзэж болно.
 */
Elm *get(Elm *ptr ,int x ){
    if(ptr==NULL || ptr->x ==x){
        return ptr;
    }
    else{
        if(ptr->x < x){
                return get(ptr->R , x);
        }
        else{
                return get(ptr->L , x);
        }
    }
}
Elm *avl_get(const AVL *ptree, int x)
{
        // Функцийг хэрэгжүүлнэ үү
        if(!ptree->root){
            return NULL;
        }
        else{
            return get(ptree->root , x);
        }
}

/*
  Устгах функц: ТМноос x утгыг хайж олоод устгана.
  Олдохгүй бол юу ч хийхгүй.
  Хэрэв мод тэнцвэрээ алдсан бол тохирох тэнцвэржүүлэх үйлдлүүдийг хийнэ.
 */
Elm *min(Elm *ptr)
{
    Elm *new = ptr;
    while (new &&new->L != NULL)
    {
        new = new->L;
    }
    return new;
}
Elm *delete(Elm *ptr, int x)
{
    if (ptr == NULL)
        return ptr;
    if (x < ptr->x)
        ptr->L = delete(ptr->L, x);
    else if (x > ptr->x)
        ptr->R = delete(ptr->R, x);
    else {
        if (ptr->L==NULL && ptr->R==NULL){
            free(ptr);
            return NULL;
        }
        else if (ptr->L == NULL) {
            Elm *temp = ptr->R;
            free(ptr);
            return temp;
        }
        else if (ptr->R == NULL) {
            Elm* temp = ptr->L;
            free(ptr);
            return temp;
        }
        Elm *temp = min(ptr->R);
        if(temp == NULL) temp = ptr;
        ptr->x = temp->x;
        ptr->R = delete(ptr->R, temp->x);
    }
        ptr->height = 1 + max(ptr->L, ptr->R);
        ptr->len = len(ptr);
        return balance(ptr);
}
void avl_del(AVL *ptree, int x)
{
    // Функцийг хэрэгжүүлнэ үү
    ptree->root = delete(ptree->root, x);
}

/*
  Хамгийн багыг устгах функц: ТМноос хамгийг бага утгыг нь устгах функц.
  Устгасан утгыг буцаана.
  Хэрэв мод тэнцвэрээ алдсан бол тохирох тэнцвэржүүлэх үйлдлүүдийг хийнэ.
 */
int avl_delMin(AVL *ptree)
{
    // Функцийг хэрэгжүүлнэ үү
    Elm *a;
    int n;
    a = min(ptree->root);
    n = a->x;
    ptree->root = delete(ptree->root, a->x);
    return n;
}

/*
  ТМыг inorder дарааллаар, нэг мөрөнд нэг утга хэвлэнэ.
 */
void inorder(Elm *ptr)
{
    if (ptr != NULL)
    {
        inorder(ptr->L);
        printf("%d %d %d\n", ptr->x, ptr->len, ptr->height);
        inorder(ptr->R);
    }
}
void avl_inorder(const AVL *ptree)
{
    // Функцийг хэрэгжүүлнэ үү
    inorder(ptree->root);
}

/*
  ТМноос x утгатай оройг хайж олоод, тухайн оройд суурилсан
  дэд модонд хэдэн орой байгааг олж буцаана.
  Олдохгүй бол -1-ийг буцаана.
 */


int avl_size(const AVL *ptree, int x)
{
        // Функцийг хэрэгжүүлнэ үү
    Elm *ptr = avl_get(ptree, x );
    if(ptr != NULL)
        return len(ptr);
    else
        return -1;

}
/*
  ТМноос x утгатай оройг хайж олоод, тухайн оройд суурилсан
  дэд модны өндөр хэд байгааг олж буцаана. Олдохгүй бол -1-ийг буцаана.
 */
int height(Elm *ptr)
{
    if(ptr == NULL)
        return -1;
    else
    {
        int L=height(ptr->L);
        int R=height(ptr->R);
        if (L > R)
            return L+1;
        else
            return R+1;
    }
}

int avl_height(const AVL *ptree, int x)
{
        // Функцийг хэрэгжүүлнэ үү
    Elm *ptr = avl_get(ptree, x );
    if(ptr != NULL)
        return height(ptr)+1;
    else
        return -1;
}