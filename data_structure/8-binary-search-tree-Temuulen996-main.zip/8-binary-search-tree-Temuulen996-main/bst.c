#include "DS.h"
/*
  `ptree`-ийн зааж байгаа модонд `x` утгыг оруулна.
  Оруулахдаа хоёртын хайлтын модны зарчмаар оруулах бөгөөд оруулсан
  байрлалаас дээшхи өвөг эцгийн `len`, `height` утгууд өөрчлөгдөнө.
  Мод хоосон байсан бол `ptree->root` хаяг өөрчлөгдөж шинээр орсон оройг заана.
 */

// void changeHeight(Elm *ptr){
//         if (ptr == NULL )return;
//         int leftSideHeigh;
//         int rightSideHeight;
//         if(ptr->L == NULL) leftSideHeigh = 1; //zuun huuuhedgui bol zuun taliin niit ondr 1 bolno.
//         else leftSideHeigh = ptr->L->height +1; // ugui bol zuun taliin niit ondor zuun huuhdiin ondor deer ooriigoo nemsentei tentsuu
//         if(ptr->R == NULL) rightSideHeight = 1;
//         else rightSideHeight = ptr->R->height +1;
//         if(leftSideHeigh > rightSideHeight ) ptr->height = leftSideHeigh;
//         else ptr->height = rightSideHeight;
// }
// void changeLen(Elm *ptr){
//         if (ptr == NULL )return;
//         if(ptr->L == NULL) {
//                 if(ptr->R !=NULL){
//                         ptr->len = ptr->R->len+1;
//                 }
//                 else{
//                         ptr->len == 1;
//                 }
//         }
        
//         else if(ptr->R == NULL) {
//                 if(ptr->L !=NULL){
//                         ptr->len = ptr->L->len+1;
//                 }
//                 else {
//                         ptr->len = 1;
//                 }
//         }
//         else ptr->len = ptr->L->len + ptr->R->len +1;
// }
Elm *createElement(int x){
        Elm *ptr = (Elm *) malloc(sizeof(Elm)) ;
        ptr->x = x ;
        ptr->height = ptr->len = 1 ;
        ptr->R = ptr->L = NULL ;
        return ptr;
}
void insert(Elm *p, int x){
        if (p->x > x){
                if (p->L == NULL)
                {
                        p->L = createElement(x);
                }
                else
                        insert(p->L, x);
                }
        else {
                if (p->R == NULL)
                {
                        p->R = createElement(x);
                }
                else
                        insert(p->R, x);
        }
        p->len = size(p);
        p->height = height(p)+1;
}
void bs_put(BST *ptree, int x)
{
        if (ptree->root == NULL){ 
                ptree->root = createElement(x);
                return;
        }
        insert(ptree->root, x);

}
Elm *get( Elm *ptr ,int x ){
        if(ptr==NULL || ptr->x ==x){
                return ptr;
        }
        else{
                if(ptr->x < x){
                        return get(ptr->R , x);
                }
                else{
                        return get(ptr->L , x);
                }
        }
}
/*
  `ptree`-ийн зааж байгаа модноос `x` утгыг хайн олдсон оройн `Elm*` хаягийг буцаана.
  Олдохгүй бол `NULL` хаягийг буцаана.
  Мод дандаа ялгаатай элементүүд хадгална гэж үзэж болно.
 */
Elm *bs_get(const BST *ptree, int x)
{
        if(!ptree->root){
                return NULL;
        }
        else{
                return get(ptree->root , x);
        }
}
  Elm *delmin2(Elm *p)
 {
     Elm* curr = p;
     while(curr && curr->L != NULL)
            curr = curr->L;
        return curr;
 }
/*
  Устгах функц: ХХМноос `x` утгыг хайж олоод устгана.
  Олдохгүй бол юу ч хийхгүй.
 */
Elm *delete(Elm *ptr, int x){
        if (ptr == NULL)
                return ptr;
        if (x < ptr->x)
                ptr->L = delete(ptr->L, x);
        else if (x > ptr->x)
                ptr->R = delete(ptr->R, x);
        else {
                if (ptr->L==NULL && ptr->R==NULL){
                        free(ptr);
                        return NULL;
                }
                else if (ptr->L == NULL) {
                        Elm *temp = ptr->R;
                        free(ptr);
                        return temp;
                }
                else if (ptr->R == NULL) {
                        Elm* temp = ptr->L;
                        free(ptr);
                        return temp;
                }
                Elm *temp = delmin2(ptr->R);
                if(temp == NULL) temp = ptr;
                ptr->x = temp->x;
                ptr->R = delete(ptr->R, temp->x);
        }
        ptr->len = size(ptr);
        ptr->height = height(ptr)+1;
        return ptr;
        }
void bs_del(BST *ptree, int x)
{
        ptree->root = delete(ptree->root, x);
}
/*
  Хамгийн багыг устгах функц: ХХМноос хамгийг бага утгыг нь устгах функц.
  Устгасан утгыг буцаана.
 */
int bs_delMin(BST *ptree)
{
        Elm *t = delmin2(ptree->root) ;
        int a = t->x;
        bs_del(ptree, a);
        return a;
}


/*
  ХХМыг inorder дарааллаар, нэг мөрөнд нэг утга хэвлэнэ.
 */
void inorder(Elm *p)
{
    if (p != NULL) {
        inorder(p->L);
        printf("%d %d %d\n" ,p->x , p->len , p->height);
        inorder(p->R);
    }
}
void bs_inorder(const BST *ptree)
{
        // Функцийг хэрэгжүүлнэ үү
        inorder(ptree->root);
}

/*
  ХХМноос `x` утгаас эрс бага буюу тэнцүү байх хэдэн орой байгааг олж буцаана.
  Өөрөөр хэлбэл хоёртын хайлтын модны утгуудыг өсөх дарааллаар байрлуулбал
  `x`-ийг оролцуулаад өмнө хэдэн тоо байх вэ? гэсэн үг.
  `x` утга заавал модонд байх албагүй.
 */
int rank(Elm *ptr , int x){
        if (ptr == NULL){
                return 0;
        }
        if (ptr->x > x){
                return rank(ptr->L, x) ;
        }
        int left;
        if(ptr->L  == NULL){
                left = 1;
        }
        else{
                left = ptr->L->len +1;
        }
        return left + rank(ptr->R, x);
}
int bs_rank(const BST *ptree, int x)
{
        // Функцийг хэрэгжүүлнэ үү
        if (ptree->root != NULL){
                return rank(ptree->root, x);
        }
}
/*
  ХХМноос `x` утгатай оройг хайж олоод, тухайн оройд суурилсан
  дэд модонд хэдэн орой байгааг олж буцаана.
  Олдохгүй бол -1-ийг буцаана.
 */
 int size(Elm *p)
{
  if (p==NULL)
    return 0;
  else
    return (size(p->L) + 1 + size(p->R));
}

int bs_size(const BST *ptree, int x)
{
        // Функцийг хэрэгжүүлнэ үү
        Elm *p = bs_get(ptree, x );
        if(p != NULL)
            return size(p);
        else
            return -1;

}
/*
  XXMноос `x`-ээс бага буюу тэнцүү байх хамгийн их утгын `Elm *` хаягийг олж буцаана.
  Олдохгүй бол `NULL` хаягийг буцаана.
 */
Elm *Floor(Elm *ptr , int x ){
        if(ptr == NULL) return NULL;
        if(ptr->x == x) return ptr;
        if(ptr->x < x){
                Elm *k = Floor(ptr->R , x);
                if(k == NULL ){
                        return ptr;
                }
                else return k;
        }
        else  return Floor(ptr->L , x);
}
Elm *bs_floor(const BST *ptree, int x)
{
        if(ptree->root == NULL) return NULL;
        return Floor(ptree->root , x);
}
/*
  XXMноос `x`-ээс их буюу тэнцүү байх хамгийн бага утгын `Elm *` хаягийг олж буцаана.
  Олдохгүй бол `NULL` хаягийг буцаана.
 */
Elm *ceiling(Elm *ptr, int x){
        if (ptr == NULL) return NULL ;
        if (ptr->x < x){
                return ceiling(ptr->R, x) ;
        }
        else if (ptr->x == x) return ptr;
        else {
                Elm *t = ceiling(ptr->L, x);
                if (t == NULL)
                        return ptr;
                else
                        return t;
        }
}
Elm *bs_ceiling(const BST *ptree, int x)
{
        if (ptree->root == NULL) return NULL;
        else return ceiling(ptree->root, x);
}
/*
  ХХМноос `x` утгатай оройг хайж олоод, тухайн оройд суурилсан
  дэд модны өндөр хэд байгааг олж буцаана. Олдохгүй бол -1-ийг буцаана.
 */
 int height(Elm *p)
{
    if(p == NULL)
        return -1;
    else
    {
        int L=height(p->L);
        int R=height(p->R);
        if (L > R)
            return L+1;
        else
            return R+1;
    }
}

int bs_height(const BST *ptree, int x)
{
        // Функцийг хэрэгжүүлнэ үү
        Elm *p = bs_get(ptree, x );
        if(p != NULL)
            return height(p)+1;
        else
            return -1;
}
