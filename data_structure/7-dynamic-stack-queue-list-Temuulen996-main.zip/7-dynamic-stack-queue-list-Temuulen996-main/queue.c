#include "DS.h"

/* p-ийн зааж буй Queue-д x утгыг хийнэ */
void q_push(Queue *p, int x)
{
        Elm *pointer = (Elm *)malloc(sizeof(Elm));
        pointer->x = x;
        if(p->head == NULL){
                pointer->next = NULL;
                p->head = p->tail =  pointer;
        }
        else {
                pointer->next = NULL;
                p->tail->next =  pointer;
                p->tail = pointer;
        }
        p->len++;

}

/* p-ийн зааж буй Queue-с гаргана */
void q_pop(Queue *p)
{
        /* Энд гаргах үйлдлийг хийнэ үү */
        if(p->head != NULL){
                Elm *k = p->head->next;
                free(p->head);
                p->head = k;
        }
        p->len--;
}

/*
  p-ийн зааж буй Queue-н утгуудыг хэвлэнэ.
  Хамгийн эхний элементээс эхлэн дарааллаар, нэг мөрөнд
  нэг л элемент хэвлэнэ.
 */
void q_print(Queue *p)
{
        /* Энд хэвлэх үйлдлийг хийнэ үү */
        Elm *counter = p->head;
        for(counter = p->head ; counter !=NULL ;counter = counter->next){
                printf("%d\n" ,counter->x);
        }
}
