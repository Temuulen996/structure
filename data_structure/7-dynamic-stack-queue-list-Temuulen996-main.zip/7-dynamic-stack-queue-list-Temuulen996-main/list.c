#include "DS.h"

/* p-ийн зааж буй List-д x утгыг төгсгөлд хийнэ */
void l_push_back(List *p, int x)
{
        Elm *pointer = (Elm *)malloc(sizeof(Elm));
        pointer->x = x;
        if(p->head == NULL){
                pointer->next = NULL;
                p->head = p->tail =  pointer;
        }
        else {
                pointer->next = NULL;
                p->tail->next =  pointer;
                p->tail = pointer;
        }
        p->len++;
}

/* p-ийн зааж буй List-д x утгыг эхэнд хийнэ
   Бүх элементүүд нэг нэг байрлал хойшилно.
 */
void l_push_front(List *p, int x)
{
	/* Энд оруулах үйлдлийг хийнэ үү */
        Elm *pointer = malloc(sizeof(Elm)) ;
        pointer->x = x ;
        pointer->next = p->head ;
        if (p->head == NULL && p->tail == NULL) {
                p->head = p->tail = pointer ;
        }
        else {
                p->head = pointer ;
        }
        
        p->len++ ;
}

/*
  p-ийн зааж буй List-д x утгыг pos байрлалд хийнэ
  pos болон түүнээс хойшхи элементүүд нэг байрлал ухарна.
  Тухайн байрлал List-ийн сүүлийн индексээс их бол төгсгөлд орно.
 */
void l_insert(List *p, int x, int pos)
{
	/* Энд оруулах үйлдлийг хийнэ үү */
        if (pos == 0){
                l_push_front(p, x) ;
                return ;
        }
        if (pos == p->len){
                l_push_back(p, x) ;
                return ;
        }
        Elm *pointer = (Elm *) malloc(sizeof(Elm));
        Elm *k = p->head;
        pointer->x = x;
        int i;
        for(i=1; i<pos;  i++){
                k = k->next ;
        }
        pointer->next = k->next ;
        k->next = pointer ;
        p->len++;
}


/*
  p-ийн зааж буй List-н эхлэлээс гаргана.
  List-ийн бүх элементүүд нэг нэг байрлал урагшилна
 */
void l_pop_front(List *p)
{
	/* Энд гаргах үйлдлийг хийнэ үү */
        if(p->head != NULL){
                Elm *k = p->head->next;
                free(p->head);
                p->head = k;
        }
        p->len--;
}

/* p-ийн зааж буй List-н төгсгөлөөс гаргана */
void l_pop_back(List *p)
{
        Elm *k;
        if(p->len == 1){
                l_pop_front(p);
        }
        else if(p->head==NULL){

        } 
        else{
                
                k=p->head;
                while(k->next!=p->tail){
                        k=k->next;
                }
                free(p->tail);
                p->tail=k;
                p->tail->next=NULL;
                p->len--;
        }
        
}

/* p-ийн зааж буй List-н pos байрлалаас гаргана.
   pos болон түүнээс хойшхи элементүүд нэг байрлал урагшилна.
   pos байрлалаас гарах боломжгүй бол юу ч хийхгүй.
 */
void l_erase(List *p, int pos)
{

        Elm *k = p->head , *l;
        if (pos > 0 && pos < p->len){
                int i;
                for(i=1; i<pos; i++){
                        if (k->next !=  NULL) {
                                k = k->next ;
                        }
                }
                l=k->next;
                k->next = k->next->next ;
                free(l);
                p->len--;
        }
}

/*
  p-ийн зааж буй List-н утгуудыг хэвлэнэ.
  Хамгийн эхний элементээс эхлэн дарааллаар, нэг мөрөнд
  нэг л элемент хэвлэнэ.
 */
void l_print(List *p)
{
        /* Энд хэвлэх үйлдлийг хийнэ үү */
        Elm *counter;
        for(counter = p->head ; counter !=NULL ;counter = counter->next){
                printf("%d\n" ,counter->x);
        }
}

/*
  p-ийн зааж буй List-с x тоог хайн олдсон хаягийг буцаана.
  Олдохгүй бол NULL хаяг буцаана.
 */
Elm *l_search(List *p, int x)
{
        Elm *k = NULL ;
        int count = 0 ; 
        for(k = p->head; k != NULL; k = k->next) {
                if (k->x == x){   
                        k = k ;
                break ;
                }
        }
        return k;
}
