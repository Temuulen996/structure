#include "DS.h"

static void swim(Heap *p, int);
static void sink(Heap *p, int);

/*
  Хоёр зурвасын чухлыг харьцуулах функц.
  b нь илүү чухал бол 1, бусад үед 0-ыг буцаах функц.
  Өөрөөр хэлбэл a < b үйлдэл юм.
*/
int less(const Msg *a, const Msg *b)
{
        // Энд жиших үйлдийг хийнэ
        if (a->priority > b->priority){
                return 1 ;
        }
        if (a->priority < b->priority){
                return 0 ;  
        }            
        if (a->time > b->time){  
                return 1 ;     
        }
        else {  
                return 0; 
        }  
} 

/*
  Оруулах функц. heap зарчмаар чухлын дарааллыг баримтлан оруулна.
  Ингэхдээ хамгийн чухал зурвас heap-ын оройд хадгалагдана.
  x зурвасыг p-ын зааж буй heap бүтцэд оруулна.
 */
void insert(Heap *p, const Msg x)
{
        // Энд оруулах үйлдлийг хийнэ
        p->heap.a[p->heap.len] = x;
        p->heap.len++;
        swim(p,p->heap.len-1);
        
}

/*
  Heap бүтцийн swim үйлдэл.
  k нь swim үйлдлийг p-ын зааж буй heap дээр эхлүүлэх индекс.
 */
static void swim(Heap *p, int k)
{
        Msg swapper;
        while(k >= 0){ 
                if(less(&p->h_arr[(k -1)/2] , &p->h_arr[k])){
                        swapper = p->h_arr[(k -1)/2];
                        p->h_arr[(k -1)/2] = p->h_arr[k];
                        p->h_arr[k] = swapper;
                        k= (k -1)/2;
                }
                else{
                        return ;
                }
        }
}

/*
  Heap бүтцийн sink үйлдэл.
  k нь sink үйлдлийг p-ын зааж буй heap дээр эхлүүлэх индекс.
 */
static void sink(Heap *p, int k)
{
        Msg swapper;
        if(k*2+1 <p->heap.len){
                if(k*2+2 <p->heap.len && less(&p->heap.a[k*2+1] ,&p->heap.a[k*2+2] )){
                        if( less(&p->heap.a[k] ,&p->heap.a[k*2+2])){
                                swapper = p->h_arr[k] ;         
                                p->h_arr[k] = p->h_arr[k*2+2] ; 
                                p->h_arr[k*2+2] = swapper ; 
                                sink(p,k*2+2); 
                        }
                        else return;
                }
                else {
                        if( less(&p->heap.a[k],&p->heap.a[k*2+1])){
                                swapper = p->h_arr[k] ;         
                                p->h_arr[k] = p->h_arr[k*2+1] ; 
                                p->h_arr[k*2+1] = swapper;  
                                sink(p,k*2+1);
                        }
                        else return;
                }

        }
        else return;
}

/*
  p-ын зааж буй heap бүтцээс оройн элементийг гаргаад буцаах функц.
  Гаргасны дараа орой бүрийн хувьд heap зарчим хадгалах ёстой.
 */
Msg delMin(Heap *p)
{
        // Энд хамгийн багыг гаргах үйлдлийг хийнэ
        Msg root = p->h_arr[0],swapper;
        swapper = p->h_arr[0] ; 
        p->h_arr[0] = p->h_arr[p->h_len - 1] ; 
        p->h_arr[p->h_len - 1] = swapper; 
        p->h_len-- ;
        sink(p, 0) ;
        return root ;
}
