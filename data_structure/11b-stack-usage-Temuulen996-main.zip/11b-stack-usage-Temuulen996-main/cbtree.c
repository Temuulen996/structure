#include "DS.h"

/*
  p-ийн зааж буй CBTree-д x утгыг оруулна
*/
void cb_push(CBTree *p, int x)
{
        /* Энд оруулах үйлдлийг хийнэ үү */
        p->cb_arr[p->cb_len] = x ;
        p->cb_len++ ;
}

/*
  p-ийн зааж буй CBTree-д idx индекстэй оройны зүүн хүүгийн индексийг буцаана.
  Зүүн хүү байхгүй бол -1 буцаана.
*/
int cb_left(const CBTree *p, int idx)
{
        /* Энд зүүн хүүхдийн индексийг буцаах үйлдлийг хийнэ үү */
        if(idx>0 && idx<p->tree.len){
                if(p->tree.len > 2*idx +1 ){
                        return 2*idx +1;
                }
                else {
                        return -1;
                }
        }
}

/*
  p-ийн зааж буй CBTree-д idx индекстэй оройны баруун хүүгийн индексийг буцаана.
  Баруун хүү байхгүй бол -1 буцаана.
*/
int cb_right(const CBTree *p, int idx)
{
        /* Энд баруун хүүхдийн индексийг буцаах үйлдлийг хийнэ үү */
        if(idx>0 && idx<p->tree.len){
                if(p->tree.len > 2*idx +2 ){
                        return 2*idx +2;
                }
                else {
                        return -1;
                }
        }
}

/*
  p-ийн зааж буй CBTree-с x тоог хайн
  хамгийн эхэнд олдсон индексийг буцаана.
  Олдохгүй бол -1 утгыг буцаана.
*/
int cb_search(const CBTree *p, int x)
{
        /* Энд хайх үйлдлийг хийнэ */	
        int  i=0;
        for(;i<p->tree.len ; i++){
                if(p->tree.a[i]==x){
                        return i;
                }
        }
        return -1;
}

/*
  p-ийн зааж буй CBTree-д idx индекстэй зангилаанаас дээшхи бүх өвөг эцэгийг олох үйлдлийг хийнэ.
  Тухайн орой өөрөө өвөг эцэгт орохгүй.
  Өвөг эцэг бүрийг нэг шинэ мөрөнд хэвлэнэ. Өвөг эцэгийг доороос дээшхи дарааллаар хэвлэнэ.
*/
void cb_ancestors(const CBTree *p, int idx)
{
        /* Энд өвөг эцгийг олох үйлдлийг хийнэ үү */
        if(idx>0 && idx<p->tree.len){
                int  i = idx ;
                while( i > 0){
                        i = (i - 1)/2;
                        printf("%d\n" , p->tree.a[i]);
                }
        }
}

/*
  p-ийн зааж буй CBTree-ийн өндрийг буцаана
*/
int cb_height(const CBTree *p)
{
        /* Энд өндрийг олох үйлдлийг хийнэ */
        int  height=0  , i = 0;
        while(i<p->tree.len) { 
                        i = 2*i+1;
                        height++;
        }
        return height;
}

/*
  p-ийн зааж буй CBTree-д idx оройны ах, дүү оройн дугаарыг буцаана.
  Тухайн оройн эцэгтэй адил эцэгтэй орой.
  Ах, дүү нь байхгүй бол -1-г буцаана.
*/
int cb_sibling(const CBTree *p, int idx)
{
        /* Энд ах, дүүг олох үйлдлийг хийнэ үү */
        if(idx>0 && idx<p->tree.len){
                int  i=(idx-1)/2;
                if(p->tree.a[2*i+1] == p->tree.a[idx]){
                        if(2*i+2 > p->tree.len-1) return -1;
                        return (2*i+2);
                }
                else {
                        if(2*i+2 > p->tree.len-1) return -1;
                        return (2*i+1);
                }
        }
        else {
                return -1;
        }
}

/*
  p-ийн зааж буй CBTree-г idx дугаартай зангилаанаас эхлэн preorder-оор хэвлэ.
  Орой бүрийг нэг шинэ мөрөнд хэвлэнэ.
*/
void cb_preorder(const CBTree *p, int idx)
{
        /* Энд pre-order-оор хэвлэх үйлдлийг хийнэ үү */
        Stack *st = (struct Stack *)malloc(sizeof(Stack));
        st->len = 0;
        st->top = NULL;
        s_push(st , idx);
        while(st->top != NULL){
                if(st->top->x >= p->tree.len){
                        s_pop(st);
                }
                else{
                        int k=st->top->x;
                        printf("%d\n",p->tree.a[k]);
                        s_pop(st);
                        s_push(st,k*2+2);
                        s_push(st,k*2+1);     
                }
        }
        free(st);
}

/*
  p-ийн зааж буй CBTree-г idx дугаартай зангилаанаас эхлэн in-order-оор хэвлэ.
  Орой бүрийг нэг шинэ мөрөнд хэвлэнэ.
*/
void cb_inorder(const CBTree *p, int idx)
{
        /* Энд in-order-оор хэвлэх үйлдлийг хийнэ үү */
        Stack *st = (struct Stack*)malloc(sizeof(Stack));
        st->len = 0;
        st->top = NULL;
        s_push(st , idx);
        int k=idx*2+1;
        while(st->top != NULL || k<p->tree.len){
                while(k<p->tree.len){//tuhain oroinii zuun talruu tultal ywj stack ruu hiine
                        s_push(st , k);
                        k = k*2+1;
                }
                k = st->top->x;// zuun talruu tulsan ucir elementiig helej bolno.
                printf("%d\n" , p->tree.a[k]);
                s_pop(st);// hewlesen ucir stack aas gargana.
                k = k*2+2;//tuhain oroini baruun taliin huuuhedruu ywna. baruun tal deeree ochood dahin zuun huuhed hurtel tultal ywna.
        }
        free(st);
}

/*
  p-ийн зааж буй CBTree-г idx дугаартай зангилаанаас эхлэн post-order-оор хэвлэ.
  Орой бүрийг нэг шинэ мөрөнд хэвлэнэ.
 */
void cb_postorder(const CBTree *p, int idx)
{
        /* Энд post-order-оор хэвлэх үйлдлийг хийнэ үү */
        Stack *st = (struct Stack*)malloc(sizeof(Stack));
        st->len = 0;
        st->top = NULL;
        Stack *st2 = (struct Stack*)malloc(sizeof(Stack));
        st2->len = 0;
        st2->top = NULL;
        s_push(st , idx);
        while(st->top != NULL){
                int k = st->top->x;
                s_pop(st);
                s_push(st2, k);
                if(k*2+1 < p->tree.len){
                        s_push(st , k*2+1);
                }
                        if(k*2+2 < p->tree.len){
                        s_push(st , k*2+2);
                }
        }
        
        while (st2->top !=NULL) {
                printf("%d\n" , p->tree.a[st2->top->x] );
                s_pop(st2);
        }
        free(st);
        free(st2);
}

/*
  p-ийн зааж буй CBTree-с idx дугаартай зангилаанаас доошхи бүх навчийг олно.
  Навч тус бүрийн утгыг шинэ мөрөнд хэвлэнэ.
  Навчыг зүүнээс баруун тийш олдох дарааллаар хэвлэнэ.
*/
void cb_leaves(const CBTree *p, int idx)
{
        /* Энд навчуудыг үйлдлийг хийнэ үү */
        int  i=idx;
        if(i<p->tree.len){
                if(2*i+1 > p->tree.len-1 && 2*i+2 > p->tree.len-1 ){
                        printf("%d\n" , p->tree.a[i]);
                }       
                else{
                        cb_leaves(p , 2*i+1);
                        cb_leaves(p , 2*i+2);
                }
        }
}

/*
  p-ийн зааж буй CBTree-д idx индекстэй оройноос доошхи бүх үр садыг хэвлэнэ.
  Тухайн орой өөрөө үр сад болохгүй.
  Үр, сад бүрийг нэг шинэ мөрөнд хэвлэнэ. Үр садыг pre-order дарааллаар хэлэх ёстой.
*/
void cb_descendants(const CBTree *p, int idx)
{
        /* Энд үр садыг олох үйлдлийг хийнэ үү */
        if (idx<p->tree.len){
                cb_preorder(p , (idx*2+1));
                cb_preorder(p , (idx*2+2));
        }
}


/*
  p-ийн зааж буй Tree-д хэдэн элемент байгааг буцаана.
  CBTree-д өөрчлөлт оруулахгүй.
*/
int cb_size(const CBTree *p)
{
        /* Энд хэмжээг олох үйлдлийг хийнэ үү */
        return p->tree.len;		
}


/*
  p-ийн зааж буй CBTree-д x утгаас үндэс хүртэлх оройнуудын тоог буцаана.
  x тоо олдохгүй бол -1-г буцаана.
*/
int cb_level(const CBTree *p, int x)
{
        /* Энд түвшинг олох үйлдлийг хийнэ үү */
        int ancestors = 0 , index = cb_search(p,x);
        if(index == -1) return -1;
        int  i = index ;
        while( i > 0){
                i = (i - 1)/2;
                ancestors++;
        }
        return ancestors;
}




// void cb_preorder(const CBTree *p, int idx)
// {
//         /* Энд pre-order-оор хэвлэх үйлдлийг хийнэ үү */
//         Stack a;
//         a.len = 0;
//         a.top = NULL;
//         s_push(&a,idx);
//         while (a.len > 0)
//         {
//             if (a.top->r == 2)
//             {
//                 s_pop(&a);
//             }
//             else if (a.top->r == 0)
//             {
//                 a.top->r++;
//                 if (a.top->x < p->cb_len)
//                 {
//                     printf("%d\n", p->cb_arr[a.top->x]);
//                     s_push(&a,a.top->x*2+1);
//                 }
//             }
//             else if (a.top->r == 1)
//             {
//                 a.top->r++;
//                 if (a.top->x < p->cb_len)
//                 {
//                     s_push(&a,a.top->x*2+2);
//                 }
//             }
//         }
// }

// /*
//   p-ийн зааж буй CBTree-г idx дугаартай зангилаанаас эхлэн in-order-оор хэвлэ.
//   Орой бүрийг нэг шинэ мөрөнд хэвлэнэ.
// */
// void cb_inorder(const CBTree *p, int idx)
// {
//         /* Энд in-order-оор хэвлэх үйлдлийг хийнэ үү */
//         Stack a;
//         a.len = 0;
//         a.top = NULL;
//         s_push(&a,idx);
//         while (a.len > 0)
//         {
//             if (a.top->r == 2)
//             {
//                 s_pop(&a);
//             }
//             else if (a.top->r == 0)
//             {
//                 a.top->r++;
//                 if (a.top->x < p->cb_len)
//                 {
//                     s_push(&a,a.top->x*2+1);
//                 }
//             }
//             else if (a.top->r == 1)
//             {
//                 a.top->r++;
//                 if (a.top->x < p->cb_len)
//                 {
//                     printf("%d\n", p->cb_arr[a.top->x]);
//                     s_push(&a,a.top->x*2+2);
//                 }
//             }
//         }
// }

// /*
//   p-ийн зааж буй CBTree-г idx дугаартай зангилаанаас эхлэн post-order-оор хэвлэ.
//   Орой бүрийг нэг шинэ мөрөнд хэвлэнэ.
//  */
// void cb_postorder(const CBTree *p, int idx)
// {
//         /* Энд post-order-оор хэвлэх үйлдлийг хийнэ үү */
//         Stack a;
//         a.len = 0;
//         a.top = NULL;
//         s_push(&a,idx);
//         while (a.len > 0)
//         {
//             if (a.top->r == 2)
//             {
//                 if (a.top->x < p->cb_len)
//                     printf("%d\n", p->cb_arr[a.top->x]);
//                 s_pop(&a);
//             }
//             else if (a.top->r == 0)
//             {
//                 a.top->r++;
//                 if (a.top->x < p->cb_len)
//                 {
//                     s_push(&a,a.top->x*2+1);
//                 }
//             }
//             else if (a.top->r == 1)
//             {
//                 a.top->r++;
//                 if (a.top->x < p->cb_len)
//                 {
//                     s_push(&a,a.top->x*2+2);
//                 }
//             }
//         }
// }