#include "myinclude.h"

void read(int A[], int n)
{
        int i;
        for (i = 0; i < n; i++)
                scanf("%d", &A[i]);
}

void print(int A[], int n)
{
        int i;
        for (i = 0; i < n; i++)
                printf("%d ", A[i]);
        printf("\n");
}

int max(int A[], int n)
{
       
        int max  = A[0];
        int  i = 1 ;
        while( i < n ){
                if(max <= A[i]){
                        max = A[i];
                }
                i++;
        }
        return max;
}

int min(int A[], int n)
{
        
        int min = A[0];
        int i = 1 ;
        while(i < n){
                if(min >= A[i]){
                        min = A[i];
                }
                i++;
        }       
        return min;
}

void copy(int A[], int n, int B[])
{
        
        int  i = 0; 
        while( i < n ){
                *(B+i) = *(A+i); 
                i++;
        }      
}

int find(int A[], int n, int x)
{
        
        int count = 0;
        int index =0; 
        int i = 0;
        while( i < n ){
                if(count == 0){
                        if(*(A+i) == x){
                                index = i;
				count++;
                        }
                }
				i++;
        }        
        if(count == 0){
                return -1;
        }
        else{
                return index;
        }
}

int make_set(int A[], int n, int B[])
{
        B[0] = A[0];
        int i = 1 ,count ; 
        int index_of_B=1;
	while(i< n ){
		count = 0;
		int  j = 0; 
		while(j < index_of_B){
			if(A[i] == B[j]){
				count++;
			}
			j++;
		}
                if(count == 0 ){
                        B[index_of_B] = A[i];
                        index_of_B++;
                }
		i++;
	}
    return index_of_B;
}
int union_set(int A[], int n, int B[], int m)
{
		int added=0,count ;
		int i = 0  ; 
		while(i <  m ){
			int j  = 0 ; 
			count=0;
			while(j < (n+added)){
				if(B[i] == A[j]){
					count++;
				}
				j++;
			}
			if(count  == 0){
				A[n+added] = B[i];
				added++;
			}
			i++;
		}  
		return (n+added);       
}

int intersection_set(int A[], int n, int B[], int m, int C[])
{
                int i = 0 , count ,indx=0; 
		while(i < n){
			count = 0 ;
			int j = 0 ; 
			while(j < m){
				if(A[i] == B[j]){
					count++;
				}
				j++;
			}
			if(count >= 1 ){
				C[indx]=A[i];
				indx++;
			}
			i++;
		}
                return indx; 
}