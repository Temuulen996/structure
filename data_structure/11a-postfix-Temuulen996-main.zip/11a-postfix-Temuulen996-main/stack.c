#include "DS.h"
/*
  p-ийн зааж буй Stack-т x утгыг оруулна
 */
void s_push(Stack *p, int x)
{
        /* Энд оруулах үйлдлийг хийнэ үү */
        Elm *pointer = (Elm *)malloc(sizeof(Elm));
        pointer->x = x;
        if(p->top == NULL){
                p->top=pointer;
                p->top->next =NULL;
        }
        else{
                pointer->next = p->top;
                p->top = pointer;
        }
        p->len++;
}
/*
  p-ийн зааж буй Stack-аас гарах функц
 */
void s_pop(Stack *p)
{
        /* Энд гаргах үйлдлийг хийнэ үү */
        Elm *pointer;
        if(p->top != NULL){
                if(p->top->next == NULL){
                        free(p->top);
                        p->top= NULL;
                }
                else{
                        pointer = p->top->next;
                        free(p->top);
                        p->top = pointer;
                }
        }
        p->len--;
}
/*
    p-ийн зааж буй Stack-д байгаа элементүүдийг хэвлэх функц.
    Хамгийн сүүлд орсон элементээс эхлэн дарааллаар, нэг мөрөнд
    нэг л элемент хэвлэнэ.
 */
void s_print(Stack *p)
{
        /* Энд хэвлэх үйлдлийг хийнэ үү */
        Elm *pointer;
        
        for( pointer =p->top ; pointer!=NULL ; pointer =pointer->next){
                printf("%d\n" , pointer->x);
        }
}