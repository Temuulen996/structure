#include "DS.h"

int is_space(int x)
{
        switch(x) {
        case ' ':
        case '\t':
        case '\n':
        case '\r':
        case '\f':
        case '\v':
        case '\0':
                return 1;
        default:
                return 0;
        }
        return 0;
}

int convert_to_int(const char s[])
{
	int len = strlen(s);
	int t = 0, i;
	for (i = 0; i < len; i++)
		t = t * 10 + s[i] - '0';
	return t;
}

void tokenize(const char s[], List *p_list)
{
	char tmp[EQUATION_LENGTH];
	int i, j, k, len;
	j = 0;
	struct Token x;
	len = strlen(s);
	for (i = 0; i <= len; i++) {
		if ('0' <= s[i] && s[i] <= '9') {
			/* цифр орж ирлээ */
			tmp[j] = s[i];
			j++;
		} else {
			/* тэмдэгт орж ирлээ */
			if (j != 0) { /* Хөрвүүлэх тоо байгаа эсэх */
				tmp[j] = '\0';
				j = 0;
				/* хадгалсан цифрийн цувааг int-рүү хөрвүүл */
				k = convert_to_int(tmp);
				x.flag = 1;
				x.val = k;
				/*
				  Жагсаалтанд x элемнтийг оруулах
				  Жагсаалтын push_back функцыг дуудна
				*/
				l_push_back(p_list, x);
			}
			/*
			  тэмдэгтийг жагсаалтанд оруулах
			  Жагсаалтын push_back функцыг дуудна
			 */
			if (is_space(s[i])) /* хоосон зай, шинэ мөрийг хаяна. */
				continue;

            /*
              Энд +, -, *, /, (, ) тэмдэгтүүдийг жагсаалтад оруулна.
             */
			x.flag = 0;
			x.op = s[i];
			l_push_back(p_list, x);
		}
	}

	/* Тэмдэгтэн цуваанаас салгасан тэгшитгэлийг хэвлэх
	   Жагсаалтын print функцыг дуудна.
	 */
	//  l_print(p_list); 
}

/*
  p_token - жагсаалтад байгаа тэгштгэлийг postfix-рүү хөрвүүлнэ
 */
void convert_to_postfix(List *p_token, List *p_post)
{
	Stack *st = malloc(sizeof(Stack)) ;
	st->len = 0 ;
	st->top = NULL ;
	TokenElm *k = p_token->head;
	while(k !=NULL){
		if(k->x.flag == 1){
			l_push_back(p_post , k->x);
		}
		else{
			if(k->x.flag == 0){
				int ascii = k->x.op;
				if(st->len == 0 || ascii == 40 ){
					// ( taarwal stack ruu shuud hiine.
					s_push(st , ascii);
				}
				else if(ascii == 41){
					// ) taarwal ( haalt hurtel buh operatoriig listruu hiih heregtei.
					while(st->top->x != 40){
						Token newToken;
						newToken.flag = 0;
						newToken.op = st->top->x;
						l_push_back(p_post ,newToken);
						s_pop(st);
					}
					s_pop(st);
				}
				else if(ascii == '+' || ascii == '-'){ // tuhain operator + - bol haalt taarah eswel hemjee duusah hurtel omno ni orson operatoruudaa list ruu hiih ystoi. yagaad gewel ijin erembetei operatoruud neg dor baij bolohgui mon * / % iin omno + - hiigddeggui uchraas turuuleed gardag.
					while(st->len > 0 && st->top->x != '('){
						Token newToken;
						newToken.flag = 0;
						newToken.op = st->top->x;
						l_push_back(p_post ,newToken);
						s_pop(st);
					}
					s_push(st , ascii);
				}
				else if(ascii == '/' || ascii == '*' || ascii == '%'){ //herew tuhain operator * / % ba stack iin top ni * / % bol zaawal stack iin top iig list ruu hiij stack ruu * / % iig oruulna
					if(st->top->x == '/' || st->top->x == '*' || st->top->x == '%'){
						Token newToken;
						newToken.flag = 0 ;
						newToken.op = st->top->x;
						s_pop(st);
						l_push_back(p_post , newToken);
					}
					s_push(st, ascii);
				}		
			}
		}
		k = k->next;
	}
	while(st->len > 0){
		// stack ruu operatoruudaa zow daraallaar hiij duusaad etsest ni list ruu stack iin elm uudee hiine.
		Token newToken;
		newToken.flag = 0 ;
		newToken.op = st->top->x;
		s_pop(st);
		l_push_back(p_post , newToken);
	}
	free(st);
}


							// Token token ;
							// token.flag = 0 ;
							// token.op = st->top->x ;
							// s_pop(st) ;
							// l_push_back(p_post, token) ;
int solve(List *p_post)
  {
// 	TokenElm *r = p_post->head;
// 	printf("postfix : ");
// 	while( r!=NULL){
		
// 		if(r->x.flag){
// 			printf("%d" , r->x.val);	
// 		}
// 		else {
// 			printf("%c" , r->x.op);
// 		}
// 		r = r->next;
// 	}
// 	printf("\n");
	Stack *st = malloc(sizeof(Stack));
	st->top = NULL;
	st->len = 0;
	TokenElm *k = p_post->head;
	int final , f, l;
	while(k!=NULL){
		if(k->x.flag == 1){ // tuhain element too baiwal shuud stack ru hiine.
			s_push(st , k->x.val);
		}
		else {//tuhain element operator baiwal stack iin deed taliin 2 element iig gargan irj buyu pop hiij hoorond ni tuhain operatoroor tootsno.
			l = st->top->x;
			s_pop(st);
			f = st->top->x;
			s_pop(st);
			if(k->x.op == '-'){

				final = f - l;
			}
			else if(k->x.op == '+'){
				final = f + l;
			}
			else if(k->x.op == '*'){
				final = f * l;
			}
			else if(k->x.op == '/'){
				final = f / l;
			}
			else if(k->x.op == '%'){
				final = f % l;
			}
			
			s_push(st , final);
		}
		k= k->next;
	}
	free(st);
	return final;
}
