#include "DS.h"

/* p-ийн зааж буй List-д x утгыг төгсгөлд хийнэ */
void l_push_back(List *p, Token x)
{
	/* Энд оруулах үйлдлийг хийнэ үү */
        TokenElm *pointer = malloc(sizeof(TokenElm)) ;
        pointer->x = x;
        if(p->head == NULL){
                pointer->next = NULL;
                p->head = p->tail =  pointer;
        }
        else {
                pointer->next = NULL;
                p->tail->next =  pointer;
                p->tail = pointer;
        }
        p->len++;
}

/* p-ийн зааж буй List-д x утгыг эхэнд хийнэ
   Бүх элементүүд нэг нэг байрлал хойшилно.
 */
void l_push_front(List *p, Token x)
{
	/* Энд оруулах үйлдлийг хийнэ үү */
        TokenElm *pointer = malloc(sizeof(TokenElm)) ;
        pointer->x = x ;
        pointer->next = p->head ;
        if (p->head == NULL && p->tail == NULL) {
                p->head = p->tail = pointer ;
        }
        else {
                p->head = pointer ;
        }
        
        p->len++ ;
}

/*
  p-ийн зааж буй List-д x утгыг pos байрлалд хийнэ
  pos болон түүнээс хойшхи элементүүд нэг байрлал ухарна.
  Тухайн байрлал List-ийн сүүлийн индексээс их бол төгсгөлд орно.
 */
void l_insert(List *p, Token x, int pos)
{
	/* Энд оруулах үйлдлийг хийнэ үү */
        if (pos == 0){
                l_push_front(p, x) ;
                return ;
        }
        if (pos == p->len){
                l_push_back(p, x) ;
                return ;
        }
        TokenElm *pointer = malloc(sizeof(TokenElm)) ;
        TokenElm *k = p->head;
        pointer->x = x;
        int i;
        for(i=1; i<pos;  i++){
                k = k->next ;
        }
        pointer->next = k->next ;
        k->next = pointer ;
        p->len++;
}


/*
  p-ийн зааж буй List-н эхлэлээс гаргана.
  List-ийн бүх элементүүд нэг нэг байрлал урагшилна
 */
void l_pop_front(List *p)
{
	/* Энд гаргах үйлдлийг хийнэ үү */
        if(p->head != NULL){
                TokenElm *k = p->head->next;
                free(p->head);
                p->head = k;
        }
        p->len--;
}

/* p-ийн зааж буй List-н төгсгөлөөс гаргана */
void l_pop_back(List *p)
{
	/* Энд гаргах үйлдлийг хийнэ үү */
        TokenElm *k;
        if(p->len == 1){
                l_pop_front(p);
        }
        else if(p->head==NULL){

        } 
        else{
                
                k=p->head;
                while(k->next!=p->tail){
                        k=k->next;
                }
                free(p->tail);
                p->tail=k;
                p->tail->next=NULL;
                p->len--;
        }
}

/* p-ийн зааж буй List-н pos байрлалаас гаргана.
   pos болон түүнээс хойшхи элементүүд нэг байрлал урагшилна.
   pos байрлалаас гарах боломжгүй бол юу ч хийхгүй.
 */
void l_erase(List *p, int pos)
{
	/* Энд гаргах үйлдлийг хийнэ үү */
        TokenElm *k = p->head , *l;
        if (pos > 0 && pos < p->len){
                int i;
                for(i=1; i<pos; i++){
                        if (k->next !=  NULL) {
                                k = k->next ;
                        }
                }
                l=k->next;
                k->next = k->next->next ;
                free(l);
                p->len--;
        }
}

/*
  p-ийн зааж буй List-н утгуудыг хэвлэнэ.
  Хамгийн эхний элементээс эхлэн дарааллаар, нэг мөрөнд
  нэг л элемент хэвлэнэ.
 */
void l_print(List *p)
{
        /* Ð­Ð½Ð´ Ñ…ÑÐ²Ð»ÑÑ… Ò¯Ð¹Ð»Ð´Ð»Ð¸Ð¹Ð³ Ñ…Ð¸Ð¹Ð½Ñ Ò¯Ò¯ */
        TokenElm *elm = p->head ;
        // List iin buh elementeer guij hevlene.
        // Ingehiin tuld head ees ehleed guine
        while(elm != NULL){
          // elm tugsguld hureegui tohioldold
          // val, op 2oo hevleed iterate hiiged yavaad baina 
          if (elm->x.flag){
            printf("%d", elm->x.val) ;
          }
          else {
            printf("%c", elm->x.op) ;
          }
          // tsaashaa iterate hiine.
          elm = elm->next ;
        }
        // break-line
        printf(" ") ;

}
